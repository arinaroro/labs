const _ = require('lodash'); 

const colors = require('./colors.json');

// Задание 1
// let res = _(colors)
//         .map(x => Object.keys(x)[0])
//         .filter(x => x.length <= 6)
//         .orderBy()
//         .value();

// console.log(res);


// Задание 2

let res = _(colors)
    .map(a => ({ color: Object.keys(a)[0], rgb: Object.values(a)[0].slice(0,3) }))
    .sortBy('color')
    .value();

console.log(res);


